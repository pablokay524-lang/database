module.exports = {
  tokenBot: "8815176244:AAEgXh_jasQunDMbZg3bkZsl7BC5XswBJhc",
  ownerID: "8421891191",
};
